-- ============================================================================
-- ArtSlot:可复用的“美术挂载位”占位组件
-- 用途:在场景里预留一块区域,美术未到位时显示占位提示;到位后两种接入方式:
--   1) 单图(立绘/图标/背景):传 image = "Textures/xxx.png"  (走 backgroundImage)
--   2) 动画精灵/复合内容: 传 children = { UI.Sprite{...}, ... }
-- 用法:
--   ArtSlot.Create({ id = "hero", label = "角色立绘", width = 200, height = 260 })
--   ArtSlot.Create({ id = "hero", image = "Textures/hero.png", width = 200, height = 260 })
-- ============================================================================
local Config = require("Core.Config")
local UI = require("urhox-libs/UI")

local ArtSlot = {}

---@param opts { id?: string, label?: string, width?: number|string, height?: number|string, image?: string, children?: table[], borderRadius?: number }
function ArtSlot.Create(opts)
    opts = opts or {}
    local hasArt = (opts.image ~= nil) or (opts.children and #opts.children > 0)

    local props = {
        id = opts.id,
        width = opts.width or 200,
        height = opts.height or 200,
        justifyContent = "center",
        alignItems = "center",
        backgroundColor = { 30, 35, 50, 140 },
        borderRadius = opts.borderRadius or 12,
        borderWidth = 1,
        borderColor = hasArt and Config.Colors.accent or Config.Colors.border,
        pointerEvents = "none",
    }

    if opts.image then
        props.backgroundImage = opts.image
        props.backgroundImageOpacity = 1
    else
        props.children = opts.children or {
            UI.Label {
                text = opts.label or "美术挂载位",
                fontSize = 13,
                fontColor = Config.Colors.textDim,
            },
        }
    end

    return UI.Panel(props)
end

return ArtSlot
