-- ============================================================================
-- HomeScene:默认首页场景(框架就绪展示 + 开发进度面板)
-- 后续可 Register 更多场景并 SceneManager.Switch 切换。
-- ============================================================================
local UI = require("urhox-libs/UI")
local Config = require("Core.Config")
local EventBus = require("Core.EventBus")
local SceneManager = require("Core.SceneManager")
local ArtSlot = require("UI.ArtSlot")

local HomeScene = {}

local uiRoot_ = nil   ---@type Widget|nil
local debugDraw_ = false
local unsubscribes_ = {} ---@type fun()[]

--- 构建 UI 树
local function BuildUI()
    uiRoot_ = UI.Panel {
        id = "homeRoot",
        width = "100%",
        height = "100%",
        backgroundColor = Config.Colors.bg,
        children = {
            -- 中央信息卡片
            UI.Panel {
                position = "absolute",
                top = 0, left = 0, right = 0, bottom = 0,
                justifyContent = "center",
                alignItems = "center",
                pointerEvents = "box-none",
                children = {
                    UI.Panel {
                        width = "90%",
                        maxWidth = 520,
                        padding = 28,
                        gap = 16,
                        backgroundColor = Config.Colors.card,
                        borderRadius = 16,
                        borderWidth = 1,
                        borderColor = Config.Colors.border,
                        alignItems = "center",
                        children = {
                            UI.Label {
                                text = Config.Title,
                                fontSize = 24,
                                fontColor = Config.Colors.textMain,
                            },
                            UI.Label {
                                text = "基础框架已就绪 · 等待玩法与美术接入",
                                fontSize = 13,
                                fontColor = Config.Colors.textDim,
                            },

                            -- 三个美术挂载位:美术资源到位后传 image 或 children
                            UI.Panel {
                                flexDirection = "row",
                                gap = 12,
                                children = {
                                    ArtSlot.Create({ id = "slotChar",   label = "角色位",  width = 140, height = 160 }),
                                    ArtSlot.Create({ id = "slotBg",     label = "背景位",  width = 140, height = 160 }),
                                    ArtSlot.Create({ id = "slotEffect", label = "特效位",  width = 140, height = 160 }),
                                },
                            },

                            UI.Button {
                                text = "发送测试事件",
                                variant = "primary",
                                onClick = function(self)
                                    EventBus.Emit("dev:test", 42)
                                end,
                            },
                        },
                    },
                },
            },

            -- 左上:当前场景与事件日志
            UI.Panel {
                id = "statusPanel",
                position = "absolute",
                top = 12, left = 12,
                padding = 10,
                gap = 4,
                backgroundColor = { 0, 0, 0, 150 },
                borderRadius = 8,
                pointerEvents = "none",
                children = {
                    UI.Label {
                        id = "sceneLabel",
                        text = "Scene: home",
                        fontSize = 12,
                        fontColor = Config.Colors.textMain,
                    },
                    UI.Label {
                        id = "eventLabel",
                        text = "Events: idle",
                        fontSize = 12,
                        fontColor = Config.Colors.textDim,
                    },
                },
            },

            -- 右上:调试面板(Z 切换)
            UI.Panel {
                id = "debugPanel",
                visible = false,
                position = "absolute",
                top = 12, right = 12,
                padding = 8,
                backgroundColor = { 0, 0, 0, 160 },
                borderRadius = 4,
                pointerEvents = "none",
                children = {
                    UI.Label {
                        id = "debugLabel",
                        text = "Debug: ON",
                        fontSize = 12,
                        fontColor = Config.Colors.textMain,
                    },
                },
            },

            -- 底部提示
            UI.Label {
                text = "'Z' 调试面板 · 'R' 重载当前场景",
                fontSize = 12,
                fontColor = Config.Colors.textDim,
                position = "absolute",
                bottom = 16, left = 0, right = 0,
                textAlign = "center",
                pointerEvents = "none",
            },
        },
    }

    UI.SetRoot(uiRoot_)
end

function HomeScene.OnEnter()
    BuildUI()

    -- 订阅示例:收到 dev:test 事件时更新状态栏,展示 EventBus 用法
    -- EventBus.On 返回 unsubscribe 函数,这里收集起来,OnLeave 时统一注销,
    -- 避免场景重载(按 R)后重复订阅导致回调叠加。
    unsubscribes_ = {}
    local off = EventBus.On("dev:test", function(value)
        if not uiRoot_ then return end
        local label = uiRoot_:FindById("eventLabel") --[[@as Label?]]
        if label then
            label:SetText("Events: dev:test -> " .. tostring(value))
        end
        print("[HomeScene] 收到事件 dev:test, value=" .. tostring(value))
    end)
    table.insert(unsubscribes_, off)

    print("[HomeScene] entered")
end

---@param dt number
function HomeScene.OnUpdate(dt)
    -- [TODO] 每帧玩法逻辑写在这里
end

---@param key number
function HomeScene.OnKey(key)
    if key == KEY_Z then
        debugDraw_ = not debugDraw_
        if uiRoot_ then
            local panel = uiRoot_:FindById("debugPanel")
            if panel then panel:SetVisible(debugDraw_) end
        end
    elseif key == KEY_R then
        -- 演示场景重载:重新进入当前场景
        SceneManager.Switch("home")
    end
end

function HomeScene.OnLeave()
    for i = 1, #unsubscribes_ do
        unsubscribes_[i]()
    end
    unsubscribes_ = {}

    if uiRoot_ then
        uiRoot_:Destroy()
        uiRoot_ = nil
    end
    print("[HomeScene] left")
end

return HomeScene
