-- ============================================================================
-- SceneManager:轻量场景注册与切换
-- 一个"场景"= 一张 table,可实现的钩子(全部可选):
--   scene:OnEnter()          进入场景时调用(构建 UI / 初始化状态)
--   scene:OnUpdate(dt)       每帧调用(游戏逻辑)
--   scene:OnLeave()         离开场景时调用(释放本场景自建资源)
--   scene:OnKey(key)         按键事件透传(key 为 KEY_* 枚举值)
-- 用法:
--   SceneManager.Register("home", HomeScene)
--   SceneManager.Switch("home")
-- ============================================================================
local SceneManager = {}

---@type table<string, table>
local scenes_ = {}
---@type table|nil
local current_ = nil
---@type string|nil
local currentName_ = nil

--- 注册场景(重复注册同名场景会覆盖)
---@param name string
---@param scene table
function SceneManager.Register(name, scene)
    scenes_[name] = scene
end

--- 切换到指定场景:先 OnLeave 旧场景,再 OnEnter 新场景
---@param name string
---@return boolean ok
function SceneManager.Switch(name)
    local nextScene = scenes_[name]
    if not nextScene then
        print("[SceneManager] 未注册的场景: " .. tostring(name))
        return false
    end

    if current_ and current_.OnLeave then
        current_:OnLeave()
    end

    current_ = nextScene
    currentName_ = name
    if current_.OnEnter then
        current_:OnEnter()
    end
    print("[SceneManager] 进入场景: " .. name)
    return true
end

--- 每帧驱动当前场景(由 main.lua 的 Update 调用)
---@param dt number
function SceneManager.Update(dt)
    if current_ and current_.OnUpdate then
        current_:OnUpdate(dt)
    end
end

--- 按键透传给当前场景
---@param key number
function SceneManager.KeyDown(key)
    if current_ and current_.OnKey then
        current_:OnKey(key)
    end
end

---@return string|nil
function SceneManager.CurrentName()
    return currentName_
end

return SceneManager
