-- ============================================================================
-- 全局配置:游戏名、主题色、后续可调参数都集中在这里
-- ============================================================================
local Config = {}

Config.Title = "My Game Project"

-- 主题配色 (RGBA 0-255),UI 统一从这里取色,方便整体换风格
Config.Colors = {
    bg        = { 24,  28,  40,  255 }, -- 场景底色
    card      = { 30,  35,  50,  230 }, -- 卡片背景
    border    = { 80,  90,  120, 100 }, -- 卡片描边
    textMain  = { 255, 255, 255, 255 }, -- 主文字
    textDim   = { 140, 160, 200, 180 }, -- 次要文字
    accent    = { 80,  140, 240, 255 }, -- 强调色
}

-- 美术资源约定路径 (相对于 assets/,资源根目录,不加 assets/ 前缀)
--   贴图/图标  ->  Textures/xxx.png
--   精灵图     ->  Sprites/xxx.png
--   音频       ->  Audio/xxx.ogg
Config.ArtPaths = {
    -- 接入美术后在这里登记,例如:
    -- player = "Sprites/player.png",
    -- bgm    = "Audio/bgm.ogg",
}

return Config
