-- ============================================================================
-- EventBus:轻量全局事件总线
-- 用途:让各模块(玩法、美术挂载、音效等)解耦通信,不直接互相 require。
--   例:Events:Emit("player:dead") 会触发所有 On("player:dead", fn) 注册的回调。
-- ============================================================================
local EventBus = {}

---@class EventBusHandler
---@field fn fun(...)
---@field once boolean|nil

-- handlers[evt] = { {fn=..., once=bool}, ... }
---@type table<string, EventBusHandler[]>
local handlers_ = {}

--- 订阅事件,返回一个 unsubscribe 函数
---@param evt string 事件名
---@param fn fun(...) 回调
---@return fun() unsubscribe
function EventBus.On(evt, fn)
    handlers_[evt] = handlers_[evt] or {}
    local entry = { fn = fn }
    table.insert(handlers_[evt], entry)
    return function()
        EventBus.Off(evt, fn)
    end
end

--- 只订阅一次
---@param evt string
---@param fn fun(...)
function EventBus.Once(evt, fn)
    handlers_[evt] = handlers_[evt] or {}
    table.insert(handlers_[evt], { fn = fn, once = true })
end

--- 取消订阅(按回调函数引用移除)
---@param evt string
---@param fn fun(...)
function EventBus.Off(evt, fn)
    local list = handlers_[evt]
    if not list then return end
    for i = #list, 1, -1 do
        if list[i].fn == fn then
            table.remove(list, i)
        end
    end
end

--- 派发事件
---@param evt string
---@vararg any
function EventBus.Emit(evt, ...)
    local list = handlers_[evt]
    if not list then return end
    -- 复制一份,避免回调里增删订阅导致遍历错乱
    ---@type EventBusHandler[]
    local snapshot = {}
    for i = 1, #list do snapshot[i] = list[i] end
    for i = 1, #snapshot do
        local e = snapshot[i]
        e.fn(...)
        if e.once then EventBus.Off(evt, e.fn) end
    end
end

--- 清空某事件或全部订阅(场景切换时可调用)
---@param evt? string
function EventBus.Clear(evt)
    if evt then handlers_[evt] = nil else handlers_ = {} end
end

return EventBus
