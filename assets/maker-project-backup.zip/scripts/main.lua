-- ============================================================================
-- My Game Project - 入口脚本(基础框架)
-- 架构分层:
--   scripts/
--     main.lua              入口:引擎生命周期 -> 分发到各模块
--     Core/Config.lua       全局配置(标题、配色、资源路径登记)
--     Core/EventBus.lua     事件总线:模块间解耦通信
--     Core/SceneManager.lua 场景管理器:注册/切换/生命周期驱动
--     UI/HomeScene.lua      默认场景(框架就绪展示,含美术挂载位示例)
--     UI/ArtSlot.lua        可复用美术挂载位组件
--   assets/
--     Textures/  贴图、图标、背景
--     Sprites/   精灵图 / 序列帧图集
--     Audio/     音效、BGM
--
-- 接入新场景流程:
--   1. scripts/UI/ 下新建 MyScene.lua,导出 {OnEnter, OnUpdate, OnKey, OnLeave}
--   2. 在下方 Start() 里 SceneManager.Register("my", MyScene)
--   3. 需要时 EventBus.Emit 或按键触发 SceneManager.Switch("my")
-- ============================================================================
local UI = require("urhox-libs/UI")
local Config = require("Core.Config")
local SceneManager = require("Core.SceneManager")
local HomeScene = require("UI.HomeScene")

-- ============================================================================
-- 生命周期
-- ============================================================================

function Start()
    graphics.windowTitle = Config.Title

    -- UI 系统初始化(自动处理 NanoVG、输入、渲染周期)
    UI.Init({
        fonts = {
            { family = "sans", weights = {
                normal = "Fonts/MiSans-Regular.ttf",
                -- bold = "Fonts/MiSans-Bold.ttf",
            } },
        },
        scale = UI.Scale.DEFAULT,
    })

    -- 注册场景(新增场景在这里登记)
    SceneManager.Register("home", HomeScene)

    -- 订阅引擎事件
    SubscribeToEvent("Update", "HandleUpdate")
    SubscribeToEvent("KeyDown", "HandleKeyDown")

    -- 进入默认场景
    SceneManager.Switch("home")

    print("=== Game Started: " .. Config.Title .. " ===")
end

function Stop()
    UI.Shutdown()
end

-- ============================================================================
-- 事件分发
-- ============================================================================

---@param eventType string
---@param eventData UpdateEventData
function HandleUpdate(eventType, eventData)
    local timeStep = eventData["TimeStep"]:GetFloat()
    SceneManager.Update(timeStep)
end

---@param eventType string
---@param eventData KeyDownEventData
function HandleKeyDown(eventType, eventData)
    local key = eventData["Key"]:GetInt()
    SceneManager.KeyDown(key)
end
